//Welcome Message
window.onload = function() { 
	alert("Welcome to Planet Pulse!");
	document.querySelector('main).classList.add('visible');
}

//Toggle dark/light mode
document.getElementBYId("toggleMode").onclick = function() {
	const body - document.body;
	if (body.style.backgroundColor=="black"){
		body.style.backgroundColor = "#f0f8ff";
		body.style.color = "black";
	} else {
	  body.style.backgroundColor = "black";
	  body.style.color = "white";
	}
};
// Navigation toggle
const menuToggle = document.getElementById('menuToggle');
const navLinks = document.getElementById('navLinks');
menuToggle.addEventListener('click', () => navLinks.classList.toggle('active'));

// Gallery logic
let currentImageIndex = 0;
const images = [
    { src: 'images/1.jpg', caption: 'Forest Recovery Project' },
    { src: 'images/2.jpg', caption: 'Ocean Cleanup Mission' },
    { src: 'images/3.jpg', caption: 'Wildlife Conservation' },
    { src: 'images/4.jpg', caption: 'Sustainable Farming' },
    { src: 'images/5.jpg', caption: 'Clean Energy in Action' },
    { src: 'images/6.jpg', caption: 'Urban Greening' },
    { src: 'images/bbb.jpg', caption: 'Recycling Awareness Campaign' },
    { src: 'images/home.jpg', caption: 'Community Tree Planting' }
];

function openLightbox(src, caption) {
    document.getElementById('lightbox-img').src = src;
    document.getElementById('lightbox-caption').textContent = caption;
    document.getElementById('lightbox').style.display = 'flex';
    document.body.style.overflow = 'hidden';
    currentImageIndex = images.findIndex(img => img.src === src);
}

function closeLightbox() {
    document.getElementById('lightbox').style.display = 'none';
    document.body.style.overflow = 'auto';
}

function changeImage(direction) {
    currentImageIndex = (currentImageIndex + direction + images.length) % images.length;
    const img = images[currentImageIndex];
    document.getElementById('lightbox-img').src = img.src;
    document.getElementById('lightbox-caption').textContent = img.caption;
}

// Lightbox close on background click
document.getElementById('lightbox').addEventListener('click', (e) => {
    if (e.target === e.currentTarget) closeLightbox();
});

// Footer clock
function updateDateTime() {
            const now = new Date();
            const options = { 
                weekday: 'long', 
                year: 'numeric', 
                month: 'long', 
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit'
            };
            document.getElementById('datetime').textContent = now.toLocaleDateString('en-US', options);
        }
		
		updateDateTime();
		setInterval(updateDateTime, 1000);
